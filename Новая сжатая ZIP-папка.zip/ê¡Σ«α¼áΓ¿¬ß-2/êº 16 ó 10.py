n = 10
m = 10
print([[(i + j) % 2 for j in range(m)] for i in range(n)])
