n, m, k = map(int,input().split())
kor = []
pole = []
for i in range(n):
    pole.append([0] * m) 

for i in range(k):
    x,y = map(int,input().split())
    x = x-1
    y = y-1
    pole[x][y] = "*"
    if x-1 >=0 and y-1>=0:
        if pole[x-1][y-1] != "*":
            pole[x-1][y-1] +=1
    if x >=0 and y-1>=0:
        if pole[x][y-1] != "*":
            pole[x][y-1] +=1
    if x+1<n and y-1>=0:
        if pole[x+1][y-1] != "*":
            pole[x+1][y-1] +=1
    if x+1 <n and y <m:
        if pole[x+1][y] != "*":
            pole[x+1][y] +=1
    if x+1 <n and y+1<m:
        if pole[x+1][y+1] != "*":
            pole[x+1][y+1] +=1
    if x <n and y+1<m:
        if pole[x][y+1] != "*":
            pole[x][y+1] +=1
    if x-1 >=0 and y+1<m:
        if pole[x-1][y+1] != "*":
            pole[x-1][y+1] +=1
    if x-1 >=0 and y>=0:
        if pole[x-1][y] != "*":
            pole[x-1][y] +=1
for i in range(n):
    print(*pole[i])

        # 0 0 0
        # 0 * 0
        # 0 0 0