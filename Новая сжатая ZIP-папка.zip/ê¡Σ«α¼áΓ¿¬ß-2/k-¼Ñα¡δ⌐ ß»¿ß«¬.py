k = int(input())
a = [0,0]
for i in range(k-1):
    a = [a,a]
print(a)

