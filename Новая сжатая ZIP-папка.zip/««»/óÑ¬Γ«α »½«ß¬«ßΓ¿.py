import math

class MyVector:
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __add__(self,other):
        x = self.x + other.x
        y = self.y + other.y
        return MyVector(x,y)
    
    def __sub__(self,other):
        x = self.x - other.x
        y = self.y - other.y
        return MyVector(x,y)
    
    def __mul__(self,num):
        x = self.x * num
        y = self.y * num
        return MyVector(x,y)
    
    def __rmul__(self,num):
        x = self.x * num
        y = self.y * num
        return MyVector(x,y)

    def __imul__(self,num):
        x = self.x * num
        y = self.y * num
        self.x = x
        self.y = y
        return self

    def __abs__(self):
        return math.sqrt(self.x**2 + self.y**2)

    def __lt__(self,other):
        return abs(self) < abs(other)
    
    def __le__(self,other):
        return abs(self) <= abs(other)
    
    def __str__(self):
        return "MyVector({}, {})".format(self.x,self.y)

v1 = MyVector(-2, 5)
v2 = MyVector(3, -4)
print(v1 + v2)
print(v1,v2)