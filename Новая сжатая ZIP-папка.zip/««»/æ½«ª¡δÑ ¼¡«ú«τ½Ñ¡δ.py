class Polynomial:
    def __init__(self,a):
        self.a = a
        self.x = 0
        
    def __add__(self,other):
        tmp = []
        max_i = 0
        if len(self.a) > len(other.a):
            for i in range(len(other.a)):
                tmp.append(self.a[i] + other.a[i])
                max_i+=1
            tmp.extend(self.a[max_i:])
        else:
            for i in range(len(self.a)):
                tmp.append(self.a[i] + other.a[i]) 
                max_i+=1
            tmp.extend(other.a[max_i:]) 
        return Polynomial(tmp)

    def __call__(self, args):
        self.x = args
        summ = self.a[0]
        for i in range(1,len(self.a)):
            summ += self.a[i]*args**i
        return summ



poly1 = Polynomial([0, 1,3])
poly2 = Polynomial([10])
poly3 = poly1 + poly2
poly4 = poly2 + poly1
print(poly3(-2), poly4(-2))
print(poly3(-1), poly4(-1))
print(poly3(0), poly4(0))
print(poly3(1), poly4(1))
print(poly3(2), poly4(2))